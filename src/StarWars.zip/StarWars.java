import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StarWars extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StarWars frame = new StarWars();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	private int num;
	
	private int thisNum;
    private int numOc;
    private int numOcCent;
    private int numOcDr;
    private boolean izButtonPressed = false;
    private boolean centButtonPressed = false;
    private boolean drButtonPressed = false;
	
	public StarWars() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 810, 635);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		num=(int) (Math.random() * 10 + 1);

		thisNum=num;
		ImageIcon imgMuneco = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\"+num+".jpg");
		JLabel Muneco = new JLabel(imgMuneco);
		Muneco.setBounds(290, 31, 225, 225);
		contentPane.add(Muneco);
		
		ImageIcon imgFondo = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\Fondo pantalla.jpg");
		JLabel fondo= new JLabel(imgFondo);
		fondo.setBounds(0,0,810,635);
		contentPane.add(fondo);
		
		ImageIcon imgOculto = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\traseraCromo.jpg");
		JLabel oculto1 = new JLabel(imgOculto);
		oculto1.setBounds(36, 311, 225, 225);
		contentPane.add(oculto1);
		contentPane.setComponentZOrder(oculto1,0);
		
		ImageIcon imgOculto2 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\traseraCromo.jpg");
		JLabel oculto2 = new JLabel(imgOculto2);
		oculto2.setBounds(293, 311, 225, 225);
		contentPane.add(oculto2);
		contentPane.setComponentZOrder(oculto2,0);
		
		ImageIcon imgOculto3 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\traseraCromo.jpg");
		JLabel oculto3 = new JLabel(imgOculto3);
		oculto3.setBounds(549, 311, 225, 225);
		contentPane.add(oculto3);
		contentPane.setComponentZOrder(oculto3,0);
		
		JButton iz = new JButton("o Aqui");
		iz.setBounds(36, 540, 225, 30);
		contentPane.add(iz);
		iz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == iz && !izButtonPressed) {
					 generateRandomNumbersWithThisNum();
					 ImageIcon Oc1 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOc +".jpg");
					 oculto1.setIcon(Oc1);
					 izButtonPressed = true;
				
					 ImageIcon Oc2 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcCent + ".jpg");
					 oculto2.setIcon(Oc2);
					 centButtonPressed = true;
					 
					 ImageIcon Oc3 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcDr + ".jpg");
					 oculto3.setIcon(Oc3);
					 drButtonPressed = true;
				}
			}
		});
		
		
		JButton cent = new JButton("Aqui");
		cent.setBounds(291, 540, 225, 30);
	
		contentPane.add(cent);
	
	     cent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == cent && !centButtonPressed) {
					 generateRandomNumbersWithThisNum();
					 ImageIcon Oc1 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOc +".jpg");
					 oculto1.setIcon(Oc1);
					 izButtonPressed = true;
				
					 ImageIcon Oc2 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcCent + ".jpg");
					 oculto2.setIcon(Oc2);
					 centButtonPressed = true;
					 
					 ImageIcon Oc3 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcDr + ".jpg");
					 oculto3.setIcon(Oc3);
					 drButtonPressed = true;	
					 }
				
			}
		});
		
		JButton dr = new JButton("aqui");
		dr.setBounds(550, 540, 225, 30);
		contentPane.add(dr);
		
		dr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == dr && !drButtonPressed) {
					 generateRandomNumbersWithThisNum();
					 ImageIcon Oc1 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOc +".jpg");
					 oculto1.setIcon(Oc1);
					 izButtonPressed = true;
				
					 ImageIcon Oc2 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcCent+ ".jpg");
					 oculto2.setIcon(Oc2);
					 centButtonPressed = true;
					 
					 ImageIcon Oc3 = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + numOcDr + ".jpg");
					 oculto3.setIcon(Oc3);
					 drButtonPressed = true;
				}
			}
		});
		
		JButton volver = new JButton("Volver a lanzar");
		volver.setBounds(31, 573, 738, 30);
		contentPane.add(volver);
		
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==volver) {
					int num2=(int) (Math.random() * 10 + 1);
					 ImageIcon newImgMuneco = new ImageIcon("C:\\Users\\Profesor\\Desktop\\StarWars\\" + num2 + ".jpg");
			           Muneco.setIcon(newImgMuneco);
			            oculto1.setIcon(imgOculto);
			            oculto2.setIcon(imgOculto2);
			            oculto3.setIcon(imgOculto3);
			            izButtonPressed = false;
			            centButtonPressed = false;
			            drButtonPressed = false;
				}
			}
		});
	}
	 private void generateRandomNumbersWithThisNum() {
	        List<Integer> randomNumbers = new ArrayList<>();
	        randomNumbers.add(thisNum);

	        while (randomNumbers.size() < 3) {
	            int randomNumber = (int) (Math.random() * 10 + 1);
	            if (!randomNumbers.contains(randomNumber)) {
	                randomNumbers.add(randomNumber);
	            }
	        }

	        Collections.shuffle(randomNumbers);

	        numOc = randomNumbers.get(0);
	        numOcCent = randomNumbers.get(1);
	        numOcDr = randomNumbers.get(2);

	        izButtonPressed = true;
	        centButtonPressed = true;
	        drButtonPressed = true;
	    }
	
	
}
